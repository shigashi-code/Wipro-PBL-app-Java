public class middleWay {
    public int[] middleWay(int[] a, int[] b) {
        int[] newArr = new int[2];
        newArr[0] = a[1];
        newArr[1] = b[1];

        return newArr;
    }
}