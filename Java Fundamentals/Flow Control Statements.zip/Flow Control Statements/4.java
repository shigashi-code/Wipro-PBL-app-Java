public class Assignment4 
{
	public static void main(String[] args) 
    {
		char x = 'a';
		char y = 'e';
		
		if (x < y) 
        {
			System.out.println(x + ", " + y);
		} 
        else 
        {
			System.out.println(y + ", " + x);
		}
	}
}
