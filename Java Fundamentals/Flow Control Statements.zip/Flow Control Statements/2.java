public class Assignment2 
{
	public static void main(String[] args)
	{
		int num = 10;

		if (num % 2 == 0) 
        {
			System.out.println("Entered Number is Even");
		}
		else 
        {
			System.out.println("Entered Number is Odd");
		}
	}
}
