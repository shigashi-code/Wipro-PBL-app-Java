public class Assignment2 {
	public static void main(String[] args) {
		Employee employee = new Employee("John Doe", 5000000, 2019, "321a2sd1321ad");
		System.out.println(employee);
	}
}